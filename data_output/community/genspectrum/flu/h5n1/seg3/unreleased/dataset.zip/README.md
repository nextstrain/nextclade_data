Influenza A/H5N1 dataset using [GCF_000864105.1](https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_000864105.1/) as the reference
