## Unreleased

Fix GFF3 format issues in genome annotation


## 2025-03-12T21:00:00Z

Initial release.
