# Nextclade Dataset for "OROV" L segment based on Reference "ILMD_TF29"

## Dataset Attributes

| Attribute            | Value                                       |
| -------------------- | ------------------------------------------- |
| Name                 | orov/L/tefe                                 |
| RefName              | Oropouche virus isolate ILMD_TF29 segment L |
| RefAccession         | PP154172.1                                  |

## Scope of This Dataset

The dataset aims to enable the quality control of segment L ofOropouche virus using a genome from [Tefe outbreak](https://pubmed.ncbi.nlm.nih.gov/29623245/) (ILMD_TF29) as reference.

The source code is available at [InstitutoTodosPelaSaude/nextclade-datasets-workflows](https://github.com/InstitutoTodosPelaSaude/nextclade-datasets-workflows/tree/main/orov).

For bugs, please open an [issue](https://github.com/InstitutoTodosPelaSaude/nextclade-datasets-workflows/issues).

Read more about Nextclade datasets in the Nextclade documentation: [Nextclade Datasets](https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html).
