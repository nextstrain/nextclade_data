## 2026-04-14T11:55:23Z

- Move `placementMaskRanges` to tree.json
- Unify attributes per schema update

## 2026-03-04T12:40:26Z

Initial release of a Zika Virus (zikav) dataset for genotype classification!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.htmls
