# A(H5) clade 2.3.2.1 dataset with A/duck/Vietnam/NCVD-1584/2012 reference

| attribute            | value                                    |
| -------------------- | ---------------------------------------- |
| authors              |[Jordan Ort](https://lmoncla.github.io/monclalab/team/JordanOrt/), [Louise Moncla](https://lmoncla.github.io/monclalab/team/LouiseMoncla/)|
| dataset name         | A(H5) clade 2.3.2.1 (provisional)         |
| reference strain     | A/duck/Vietnam/NCVD-1584/2012(H5N1)      |
| reference accession  | EPI424984                                |

## Authors and contacts

Maintained by: [Jordan Ort](https://lmoncla.github.io/monclalab/team/JordanOrt/)

With the help of: [Louise Moncla](https://lmoncla.github.io/monclalab/team/LouiseMoncla/), Samuel Shephard, Sonja Zolonski, Tommy Lam, Todd Davis, and Richard Neher

## Reference

See [Ort et al.](https://doi.org/10.1093/ve/veaf058) for more details on the development of this dataset. If you use these A(H5) Nextclade datasets, please cite:

Ort, J. T., Shepard, S. S., Zolnoski, S. A., Lam, T. T.-Y., Davis, C. T., Neher, R. A., & Moncla, L. H. (2025). Development of avian influenza A(H5) virus datasets for Nextclade enables rapid and accurate clade assignment. <i>Virus Evolution</i>, https://doi.org/10.1093/ve/veaf058.

## Scope of this dataset

This dataset uses an A(H5) candidate vaccine virus (CVV) from clade `2.3.2.1` (A/duck/Vietnam/NCVD-1584/2012) as a reference and is suitable for the analysis of A(H5) sequences belonging to clade `2.3.2.1` and its sub-clades `2.3.2.1a` through `2.3.2.1g`. Sequences belonging to other clades cannot be annotated by this dataset and will be left `unassigned`.

## Features

This dataset supports

 * Assignment to clades and subclades based on the provisional nomenclature defined by the FAO/WHO/WOAH H5 Nomenclature Working Group
 * Sequence quality control (QC)
 * Phylogenetic placement
 * Annotations for glycosylation sties, HA cleavage site sequence, and presence/absence of a polybasic cleavage site

## Clades of A(H5) avian influenza viruses

The FAO/WHO/WOAH H5 Nomenclature Working Group define "clades" using HA gene seguences, and define clades as genetically distinct, monophyletic groups of viruses. Viruses falling into a given clade share a common ancestor with significant bootstrap support and have low levels of within-clade diversity. [Past nomenclature updates](https://onlinelibrary.wiley.com/doi/10.1111/irv.12324) have required viruses in the same clade to be monophyletic with bootstrap suppor of at least 60%, with within-clade pairwise distances of less than 1.5%. These requirements are sometimes relaxed, and clades are periodically updated to account for expanding viral diversity.

Clade `2.3.2.1` viruses and their descendants have circulated since 2007 and are endemic in Southeast Asia. These viruses have diversified into eight additional sub-clades, named `2.3.2.1a` through `2.3.2.1g` due to high circulating diversity within the clade.
This Nextclade dataset incorporates these provisional `2.3.2.1` sub-clades.

## Alternative, and complementary approaches for A(H5) clade assignment

Two additional tools exist for assigning clades to A(H5) viruses that accommodate the recent `2.3.2.1` clade splits.

1. [LABEL](https://wonder.cdc.gov/amd/flu/label/): this command-line tool is built and maintained by Sam Shepard, and performs clade assignment for all current `2.3.2.1` and `2.3.4.4` clade splits.
2. [BVBRC Subspecies Classification Tool](https://www.bv-brc.org/app/SubspeciesClassification): this is a drag and drop tool that classifies a variety of viruses, including influenza A H1N1, H3N2, and H5N1.

The clade assignments in this Nextclade dataset were validated against LABEL assignments and shown to be generally well-matched across subclades. The figure below shows a direct comparison of assignments for 2,406 HA sequences from GISAID, performed using LABEL and this NextClade dataset for clade `2.3.2.1` and its subclades.

![Figure 1: Comparison between LABEL and Nextclade for 2.3.2.1 assignments](https://raw.githubusercontent.com/moncla-lab/h5-nextclade/refs/heads/main/figures-for-dataset-readmes/2321.svg)