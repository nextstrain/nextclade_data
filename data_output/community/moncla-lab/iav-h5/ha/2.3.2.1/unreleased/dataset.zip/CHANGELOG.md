## Unreleased

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2025-08-12T18:07:15Z

Updated README to change reference to published manuscript (https://doi.org/10.1093/ve/veaf058) and removed experimental tag from dataset.

## 2025-01-30T18:05:53Z

Updates to README, adding reference to the bioRxiv preprint on A(H5) Nextclade datasets (https://doi.org/10.1101/2025.01.07.631789) and changes for consistency with the preprint

## 2024-05-08T11:39:52Z

Initial release for Nextclade v3!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
