## 2025-09-09T12:13:13Z

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2024-05-08T11:39:52Z

Initial release of an HIV-1 dataset for subtype classification.
