# Swine Influenza A - N1

| Key                  | Value                |
| -------------------- | -------------------- |
| authors                | [Gautier Richard](https://orcid.org/0000-0003-3663-4569), [Tavis Anderson](https://orcid.org/0000-0002-3138-5535)                         |
| name                 | Swine Influenza A - N1                      |
| reference            | Inferred from A/California/07/2009 (48 mutations)         |
| reference accession  | NC_026434   |


## Scope of this dataset
This dataset uses A/California/07/2009(H1N1) as a reference sequence to assign clades to swIAV strains based on an improved OctoFlu nomenclature for the N1 subtype of the NA segment, coding for the neuraminidase protein. It supports swIAV sequences worldwide, with a focus on Europe and the USA.

## Features
This dataset supports

 * Assignment to clades based on OctoFlu work with improvements and new clades based on OFFLU data
 * Identification of glycosilation motifs
 * Sequence QC
 * Phylogenetic placement

## Citation

Gautier Richard, Benjamin C. Mollett, Pia Ryt-Hansen, Séverine Hervé, Martí Cortey Marquès, Enric Mateu, Ana Moreno, Chiara Chiapponi, Lars Erik Larsen, Timm Harder, Helen E. Everett, Gaëlle Simon. (2026). Genetic diversity and phylogeography of swine influenza A virus in 2013-2022 in Europe using a harmonized genotyping nomenclature. bioRxiv 2026.09.21.753142; doi: https://doi.org/10.64898/2026.09.21.753142

## GISAID dataset reference

EPI_SET_261013ch - https://doi.org/10.55876/gis8.261013ch

## Clades definition

| Lineage             | Clade    | Colloquial Name | Geographic Distribution (genotyping on all NCBI swIAV available on 03-05-2026)                                                                                                                  |
|---------------------|----------|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Classical swine     | N1.C.1   |                 | Brazil, Canada, China, Hong Kong, Japan, Mexico, Singapore, South Korea, Sweden, Switzerland, Taiwan, UK, USA                                                                                   |
|                     | N1.C.1.1 |                 | Argentina, Brazil, Canada, China, Hong Kong, Russia, Taiwan, USA                                                                                                                                |
|                     | N1.C.1.2 |                 | Canada, USA                                                                                                                                                                                     |
|                     | N1.C.2   |                 | Mexico, South Korea, USA                                                                                                                                                                        |
|                     | N1.C.2.1 |                 | USA                                                                                                                                                                                             |
|                     | N1.C.3   |                 | Brazil, Canada, China, Hong Kong, Mexico, South Korea, Taiwan, UK, USA                                                                                                                          |
|                     | N1.C.3.1 |                 | USA                                                                                                                                                                                             |
|                     | N1.C.3.2 |                 | USA                                                                                                                                                                                             |
| Eurasian avian (av) | N1EA.1   |                 | Austria, Belgium, Croatia, Denmark, France, Germany, Italy, Netherlands, Poland, Russia, Serbia, Spain, Switzerland, Thailand, UK                                                               |
|                     | N1EA.2   |                 | Austria, Belgium, France, Germany, Hungary, Italy, Netherlands, Poland, Portugal, Russia, Spain                                                                                                 |
|                     | N1EA.3   |                 | Croatia, Denmark, Finland, Germany, Italy, Poland, Spain, Sweden                                                                                                                                |
|                     | N1EA.4   |                 | Belgium, Cambodia, China, Croatia, Czech Republic, Denmark, France, Germany, Hong Kong, Indonesia, Ireland, Italy, Mexico, Netherlands, Poland, South Korea, Spain, Thailand, UK, USA, Viet Nam |
| Pandemic 2009 (pdm) | N1P      | pdm09           | Worldwide                                                                                                                                                                                       |
