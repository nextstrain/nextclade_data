## 2026-10-06T17:37:18Z

- 2026 Annual update: added new lineages to the classification system as determined by the scientific committee.
- Updated representative tree sequences to reduce assignment errors.
- Outgroup sequences are now labeled `unassigned` instead of `Outgroup`.
- Restored country coloring and the map using Pathoplexus country metadata where available.
- Most reference-tree tips now use Pathoplexus accessions (`PP_...`) as their identifiers.
- Corrected placement masks to match each serotype's GFF3 coding bounds and reference length.
- New lineages: 2III_C.3, 2III_D.1.2.1, 2III_D.1.2.2, 2III_D.1.2.3, 2II_D.4.1, 2II_D.4.2, 2II_F.1.1.10, 2II_F.1.1.2.1, 2II_F.1.1.2.2, 2II_F.1.1.2.3, 2II_F.1.1.9, 2V_F

## 2026-04-14T11:55:23Z

- Move `placementMaskRanges` to tree.json
- Unify attributes per schema update

## 2025-09-09T12:13:13Z

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2025-08-14T12:26:14Z

Annual update: added new lineages to the classification system as determined by the scientific committee.
Updated representative tree sequences to retain only publicly available data and to avoid assignment errors

## 2025-03-26T11:47:13Z

Fix GFF3 format issues in genome annotation


## 2024-10-17T16:48:48Z

- Update of the reference tree to avoid subclassification errors detected in other tools; We have added more representative sequences to some of the lineages.

## 2024-08-31T20:44:06Z

Initial release of a DENV-2 dataset for Lineage classification!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
