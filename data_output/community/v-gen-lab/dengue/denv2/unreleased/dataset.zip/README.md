# Nextclade Dataset for "DENV-2" Based on Reference "Thailand/CDC-16681/1964"

## Dataset Attributes

| Attribute            | Value                                    |
| -------------------- | ---------------------------------------- |
| Name                 | DENV-2                                   |
| RefName              | Thailand/CDC-16681/1964                  |
| RefAccession         | NC_001474.2                              |

## Scope of This Dataset

This dataset is based on the dengue virus lineage system from [Hill V, Cleemput S, Pereira JS, et al., 2024](https://doi.org/10.1371/journal.pbio.3002834) and is suitable for the analysis of DENV-2 viral sequences. The systems are independent, so sequences from other serotypes may be reported as `unassigned`.

## Dengue Lineages System Project

This system is built on experience developing lineage systems for other viruses of public health importance and is the result of a global collaboration of researchers and public health professionals. It aims to provide additional spatial and temporal resolution to discuss the large genetic diversity of the dengue virus. Specifically, it splits existing genotypes into smaller groups and provides a standardized, neutral naming system.

Broadly speaking, we define major and minor lineages within each genotype. These lineages are defined by the same rules but use different nomenclature. In theory, minor lineages should be more useful for country-specific questions, and major lineages for regional questions. Of course, it won't necessarily always work like that—some minor lineages are very widespread, and some major lineages are geographically limited.

The source code is available at [V-GEN-Lab/dengue-lineages-workflow](https://github.com/V-GEN-Lab/dengue-lineages-workflow).

For bugs, please open an [issue](https://github.com/V-GEN-Lab/dengue-lineages-workflow/issues).

## Maintainers and Contacts:

[James Siqueira Pereira](https://github.com/jamessiqueirap)¹ ² and [Alex Ranieri](https://github.com/alex-ranieri)¹.

## Affiliations

¹ Center for Viral Surveillance and Serological Assessment [(CeVIVAS)](https://bv.fapesp.br/en/auxilios/110575/continuous-improvement-of-vaccines-center-for-viral-surveillance-and-serological-assessment-cevivas/) at the [Butantan Institute](https://en.butantan.gov.br/).

² University of São Paulo [(USP)](https://www5.usp.br/english/institutional/).

Read more about Nextclade datasets in the Nextclade documentation: [Nextclade Datasets](https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html).

<!-- workflow:data-use:start -->
This dataset includes sequences obtained from [Pathoplexus](https://pathoplexus.org/), some of which are subject to Restricted-Use terms. Use and redistribution of these sequences must comply with the [Pathoplexus Data Use Terms](https://pathoplexus.org/about/terms-of-use/data-use-terms), including the applicable requirements for publications and preprints.
<!-- workflow:data-use:end -->
