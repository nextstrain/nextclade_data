## Unreleased

- Update of the reference tree to avoid subclassification errors detected in other tools; We have added more representative sequences to some of the lineages.

## 2024-08-31T20:44:06Z

Initial release of a DENV-2 dataset for Lineage classification!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
