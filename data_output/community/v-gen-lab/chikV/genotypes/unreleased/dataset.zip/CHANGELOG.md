## Unreleased

Initial release of a Chikungunya Virus  (chikV) dataset for genotype classification!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
