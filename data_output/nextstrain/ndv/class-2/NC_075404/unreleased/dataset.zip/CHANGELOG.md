## Unreleased

- Preview only: enable recombination detection

## 2026-09-29T08:40:32Z

 - initial release of the draft NDV class 2 dataset
 - the class 1 reference AB524405 is included in the reference tree as an outgroup, so that class 1 sequences attach to it and are reported as `class 1` instead of being placed inside the class 2 diversity
