## Unreleased

- Preview only: enable recombination detection

## 2026-09-29T08:40:32Z

 - initial release of the draft NDV class 1 dataset
 - the class 2 reference NC_075404 is included in the reference tree as an outgroup, so that class 2 sequences attach to it and are reported as `class 2` instead of being placed inside the class 1 diversity
