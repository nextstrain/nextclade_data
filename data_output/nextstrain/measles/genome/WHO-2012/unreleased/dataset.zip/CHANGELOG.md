## Unreleased

- Remove obsolete QC score-weight fields from `pathogen.json`.

## 2025-09-09T12:13:13Z

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2025-08-11T19:06:01Z

Initial release.
