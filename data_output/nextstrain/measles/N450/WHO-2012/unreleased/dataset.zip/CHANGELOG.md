## Unreleased

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2025-08-02T08:55:17Z

Fix `schemaVersion` field in `pathogen.json`.

This is a technical change. Data is unchanged.

## 2025-03-26T11:47:13Z

Fix GFF3 format issues in genome annotation

## 2024-06-07T06:48:19Z

Initial release.
