## Unreleased

Fix GFF3 format issues in genome annotation


## 2024-11-05T09:19:52Z

Initial release of yellow fever virus (prM-E region only) dataset.
