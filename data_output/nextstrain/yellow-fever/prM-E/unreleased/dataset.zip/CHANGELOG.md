## Unreleased

Initial release of yellow fever virus dataset.
