## Unreleased

 - update reference tree with more recent data.
 - include designation of B.D.E.1.1

## 2024-08-01T22:31:31Z

 - update of reference tree with additional data. No new clades.


## 2024-01-29T10:29:43Z

 - fix definitions of G_clades (legacy) for RSV-A and RSV-B

## 2024-01-16T20:31:02Z

**first release of v3 dataset.**

Updated consortium nomenclature.
