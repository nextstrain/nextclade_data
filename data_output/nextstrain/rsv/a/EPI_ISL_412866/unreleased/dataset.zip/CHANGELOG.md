## Unreleased

 - add subclades A.D.1.4-8
 - add subclades A.D.3.2-6, add representatives to A.D.3.1
 - add subclade A.D.5.4, adjust definition of A.D.5.3 to make it a clear sibling


## 2024-01-29T10:29:43Z

 - fix definitions of G_clades (legacy) for RSV-A and RSV-B


## 2024-01-16T20:31:02Z

**first release of v3 dataset.**

Updated consortium nomenclature.
