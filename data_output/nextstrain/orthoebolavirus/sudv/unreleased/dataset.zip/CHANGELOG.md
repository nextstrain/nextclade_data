## Unreleased

- Add an example mutation pattern for ADAR-like RNA editing (A>G on both strands)

## 2026-04-14T11:55:23Z

- Align `pathogen.json` metadata with the current Nextclade schema layout.

## 2025-09-24T07:29:03Z

Initial release of this dataset.
