## Unreleased

Initial release of this v3 dataset.

This dataset is similar to the v2 dataset `sars-cov-2` but translating mature proteins (nsp1-16) instead of ORF1a/b.
