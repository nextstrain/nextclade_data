## 2025-09-09T12:13:13Z

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2024-06-04T16:27:23Z

Removes redundant fields from pathogen.json. This is a technical cleanup and does not involve any changes to the actual data.

## 2024-01-16T20:31:02Z

Initial release of for non-HA/NA segments of Influenza A viruses based on genome in RefSeq.
