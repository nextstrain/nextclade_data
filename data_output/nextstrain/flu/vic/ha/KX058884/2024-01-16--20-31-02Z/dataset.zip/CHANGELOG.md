## 2024-01-16T20:31:02Z

 - fix subclade definition of C.2 and C.4

## 2023-11-18

Initial release for Nextclade v3!

 - addition of subclade [C.5.4](https://github.com/influenza-clade-nomenclature/seasonal_B-Vic_HA/blob/main/subclades/C.5.4.yml)
 - addition of subclade [C.5.5](https://github.com/influenza-clade-nomenclature/seasonal_B-Vic_HA/blob/main/subclades/C.5.5.yml)
 - addition of subclade [C.5.6](https://github.com/influenza-clade-nomenclature/seasonal_B-Vic_HA/blob/main/subclades/C.5.6.yml)
 - addition of subclade [C.5.7](https://github.com/influenza-clade-nomenclature/seasonal_B-Vic_HA/blob/main/subclades/C.5.7.yml)

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
