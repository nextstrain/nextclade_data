## Unreleased

Add schema definition url to `pathogen.json`. This is a purely technical change, for convenience of dataset authors. The data itself is not modified.

## 2025-02-25T17:00:40Z

Initial release of all segments for Influenza B(Vic). Datasets for segments other than HA and NA are "reference-only" and are based on B/Brisbane/2008.
