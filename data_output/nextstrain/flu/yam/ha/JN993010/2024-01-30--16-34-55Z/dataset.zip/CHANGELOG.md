## 2024-01-30T16:34:55Z

Fix: Add shortcut paths to maintain backwards compatibility: i.e. one can request the dataset via `nextclade dataset get --name flu_yam_ha --output-dir dataset`, using the v2 path `flu_yam_ha`, instead of requiring the full v3 path `nextstrain/flu/yam/ha/JN993010`.

## 2024-01-16T20:31:02Z

Initial release for Nextclade v3!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
