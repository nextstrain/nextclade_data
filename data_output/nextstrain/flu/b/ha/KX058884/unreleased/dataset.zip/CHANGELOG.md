## Unreleased
 - addition of subclade [C.3.3](https://github.com/influenza-clade-nomenclature/seasonal_B-Vic_HA/blob/main/subclades/C.3.3.yml)
 - inclusion of older sequences that precede the current subclade system


## 2026-01-14T08:53:00Z

Initial release
