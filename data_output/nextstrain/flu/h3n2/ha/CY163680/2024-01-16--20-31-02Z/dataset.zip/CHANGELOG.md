## 2024-01-16T20:31:02Z

Initial release for Nextclade v3!

 - Addition of subclade H.1, H.2, H.3, and H.4
 - Aliasing of G.1.3.1.1 as subclade H

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
