## 2025-08-07T09:22:32Z
 - NAI scores
 - addition of subclade [B.4.4](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/6519c11f846213aa8668976db4e6adb482ade82b/subclades/B.4.4.yml)
- addition of subclade [B.4.2.1](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/6519c11f846213aa8668976db4e6adb482ade82b/subclades/B.4.2.1.yml)
- addition of subclade [B.4.2.2](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/6519c11f846213aa8668976db4e6adb482ade82b/subclades/B.4.2.2.yml)
- addition of subclade [B.4.2.3](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/6519c11f846213aa8668976db4e6adb482ade82b/subclades/B.4.2.3.yml)


## 2025-01-22T09:54:14Z

 - update reference trees

## 2025-01-09T08:17:24Z

 - update reference tree


## 2024-11-05T09:19:52Z

 - update reference trees

## 2024-04-19T07:50:39Z

- addition of subclade [B.4.1](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/main/subclades/B.4.1.yml)
- addition of subclade [B.4.2](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/main/subclades/B.4.2.yml)
- addition of subclade [B.4.3](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/blob/main/subclades/B.4.3.yml)


## 2024-01-16T20:31:02Z

Initial release for Nextclade v3!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
