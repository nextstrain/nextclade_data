# Influenza A(H3N2) NA based on reference "A/Darwin/6/2021"

| Key                  | Value                |
| -------------------- | -------------------- |
| authors                | [Richard Neher](https://neherlab.org), [Nextstrain](https://nextstrain.org)                         |
| name                 | Influenza A H3N2 NA                      |
| reference            | A/Darwin/6/2021                      |
| dataset path         | flu/h3n2/na/EPI1857215                     |
| reference accession  | EPI1857215   |
| clade definitions  |  [github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/)  |




## Features
This dataset supports

 * Assignment to clades and subclades based on the nomenclature defined in [github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/)
 * Identification of glycosilation motifs
 * Counting of mutations in the RBD
 * Sequence QC
 * Phylogenetic placement

### Resistance mutations
Resistance markers are taken from the [summary of by the WHO/GISRS](https://www.who.int/teams/global-influenza-programme/laboratory-network/quality-assurance/antiviral-susceptibility-influenza/neuraminidase-inhibitor).



## Clades of seasonal influenza viruses

The WHO Collaborating centers **do not** define "clades" for the neuraminidase segment.

This dataset focuses on "subclades" that in analogy to the HA segment are defined to break down diversity at high resolution and allow following the spread of different viral groups.
These follow a Pango-like nomenclature consisting of a letter followed by a numbers separated by periods as in `C.1.2`.
The leading letter is an alias of a previous name.
Details of the nomenclature system can be found at [github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/](https://github.com/influenza-clade-nomenclature/seasonal_A-H3N2_NA/).

The nomenclature system is described in the following paper

[**Nomenclature for Tracking of Genetic Variation of Seasonal Influenza Viruses**](https://dx.doi.org/10.1111/irv.70230)

_Neher et al. Influenza and Other Respiratory Viruses, vol 20(2), 2026_

## What is Nextclade dataset

Read more about Nextclade datasets in Nextclade documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
