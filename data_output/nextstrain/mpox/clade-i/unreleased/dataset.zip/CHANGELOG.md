## Unreleased

- Newly released sequences are included.
- Sequences are now downloaded from Pathoplexus instead of NCBI virus, which allows inclusion of restricted-use clade I sequences from INRB (DRC).
- Based on user feedback, the QC rule for missing data (Ns) has been made more lenient.

## 2025-03-26T11:47:13Z

Fix GFF3 format issues in genome annotation

## 2024-11-19T14:18:53Z

- Newly shared sequences are now included

## 2024-08-01T22:31:31Z

Initial release of this dataset.
