## 2025-04-25T12:24:24Z

- Newly released sequences are included.
- Sequences are now downloaded from Pathoplexus instead of NCBI virus. This allows inclusion of restricted-use clade I sequences from INRB (Placide Mbala-Kingebeni's group) in the DRC. This nearly doubles clade I sequences available.
- Based on user feedback, the QC rule for missing data (Ns) has been made more lenient.
- Masked ranges that are ignored for placement have been updated.

## 2025-03-26T11:47:13Z

Fix GFF3 format issues in genome annotation

## 2024-11-19T14:18:53Z

- Newly shared sequences are now included

## 2024-08-01T22:31:31Z

Initial release of this dataset.
