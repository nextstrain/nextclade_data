## 2025-11-20T19:02:04Z

Add citation information to README.md

## 2025-11-19T20:40:14Z

Initial release of an Enterovirus D68 dataset for lineage classification!

Read more about Nextclade datasets in the documentation: https://docs.nextstrain.org/projects/nextclade/en/stable/user/datasets.html
